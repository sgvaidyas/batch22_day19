﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Batch22_day19
{
    public partial class Form1 : Form
    {
        public int x, y;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void btnbullet1_Click(object sender, EventArgs e)
        {
            
            functionmove(btnbullet1);
        }

        private void btnbullet2_Click(object sender, EventArgs e)
        {
            functionmove(btnbullet2);
        }

        private void functionmove(object sender)
        {
            Button btn = (Button)sender;
            x = btn.Location.X;
            y = btn.Location.Y;
            int wallx = btnwall.Location.X;
            for (int i=100;i<= wallx; i+=5)
            {
                btn.Location = new Point(i , y);
               
            }
        }
    }
}
