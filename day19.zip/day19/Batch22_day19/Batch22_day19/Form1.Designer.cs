﻿namespace Batch22_day19
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnbullet1 = new System.Windows.Forms.Button();
            this.btnwall = new System.Windows.Forms.Button();
            this.btnbullet2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnbullet1
            // 
            this.btnbullet1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnbullet1.Location = new System.Drawing.Point(39, 104);
            this.btnbullet1.Name = "btnbullet1";
            this.btnbullet1.Size = new System.Drawing.Size(32, 33);
            this.btnbullet1.TabIndex = 0;
            this.btnbullet1.UseVisualStyleBackColor = false;
            this.btnbullet1.Click += new System.EventHandler(this.btnbullet1_Click);
            // 
            // btnwall
            // 
            this.btnwall.BackColor = System.Drawing.Color.Maroon;
            this.btnwall.ForeColor = System.Drawing.Color.White;
            this.btnwall.Location = new System.Drawing.Point(558, 12);
            this.btnwall.Name = "btnwall";
            this.btnwall.Size = new System.Drawing.Size(75, 445);
            this.btnwall.TabIndex = 1;
            this.btnwall.Text = "wall";
            this.btnwall.UseVisualStyleBackColor = false;
            // 
            // btnbullet2
            // 
            this.btnbullet2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnbullet2.Location = new System.Drawing.Point(39, 269);
            this.btnbullet2.Name = "btnbullet2";
            this.btnbullet2.Size = new System.Drawing.Size(32, 33);
            this.btnbullet2.TabIndex = 2;
            this.btnbullet2.UseVisualStyleBackColor = false;
            this.btnbullet2.Click += new System.EventHandler(this.btnbullet2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnbullet2);
            this.Controls.Add(this.btnwall);
            this.Controls.Add(this.btnbullet1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnbullet1;
        private System.Windows.Forms.Button btnwall;
        private System.Windows.Forms.Button btnbullet2;
    }
}

